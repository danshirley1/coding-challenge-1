/* @noflow */
import React from 'react';
import {shallow} from 'enzyme';
import namedStateMessageHOC from '../namedStateMessageHOC';
import City from '../city';
import Name from '../name';

describe('namedStateMessageHOC component', () => {
    let defaultProps;

    function getWrappedComponent(component, props) {
        const Element = namedStateMessageHOC(component);
        return shallow(<Element {...props} />);
    }

    beforeEach(() => {
        defaultProps = {
            loading: false,
            error: null,
            data: null,
        };
    });

    describe('wrapped city component', () => {
        it('generates the expected component when in loading state', () => {
            const wrappedComponent = getWrappedComponent(City, {...defaultProps, loading: true});
            expect(wrappedComponent.html()).toEqual('<div>Loading...</div>');
        });

        it('generates the expected component when in error state', () => {
            const wrappedComponent = getWrappedComponent(City, {...defaultProps, error: 'BANG!'});
            expect(wrappedComponent.html()).toEqual('<div>Error!</div>');
        });

        it('generates the expected component when in named state', () => {
            const wrappedComponent = getWrappedComponent(City, {...defaultProps, data: {city: 'London'}});
            expect(wrappedComponent.html()).toEqual('<h3>London</h3>');
        });
    });

    describe('wrapped Name component', () => {
        it('generates the expected component when in loading state', () => {
            const wrappedComponent = getWrappedComponent(Name, {...defaultProps, loading: true});
            expect(wrappedComponent.html()).toEqual('<div>Loading...</div>');
        });

        it('generates the expected component when in error state', () => {
            const wrappedComponent = getWrappedComponent(Name, {...defaultProps, error: 'BANG!'});
            expect(wrappedComponent.html()).toEqual('<div>Error!</div>');
        });

        it('generates the expected component when in named state', () => {
            const wrappedComponent = getWrappedComponent(Name, {...defaultProps, data: {name: 'Donald'}});
            expect(wrappedComponent.html()).toEqual('<h2>Donald</h2>');
        });
    });
});
