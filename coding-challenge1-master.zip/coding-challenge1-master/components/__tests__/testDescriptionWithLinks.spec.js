/* @noflow */
import React from 'react';
import {shallow} from 'enzyme';
import DescriptionWithLinks from '../descriptionWithLinks';

describe('DescriptionWithLinks component', () => {
    let component;

    const defaultProps = {
        description: 'My test description',
        links: [],
    };

    const getComponent = (moreProps = {}) => {
        const componentProps = {
            ...defaultProps,
            ...moreProps,
        };

        return shallow((
            <DescriptionWithLinks {...componentProps} />
        ));
    };

    beforeEach(() => {
        component = getComponent();
    });

    it('renders the expected component output with default arguments', () => {
        expect(component.text()).toEqual('My test description');
    });

    it('renders the expected component output with a custom message', () => {
        component = getComponent({description: 'Hello world!'});
        expect(component.text()).toEqual('Hello world!');
    });

    it('renders the expected component output with custom links', () => {
        component = getComponent({
            description: 'Hello world! I see that www.example.com/1 is interesting, so is www.example.com/2 and also www.example.com/3!',
            links: [
                {
                    url: 'www.example.com/1',
                    text: 'example_1',
                },
                {
                    url: 'www.example.com/2',
                    text: 'example_2',
                },
                {
                    url: 'www.example.com/3',
                    text: 'example_3',
                }
            ],
        });

        /* eslint-disable no-multi-str */
        expect(component.html()).toEqual("<div>Hello world! I see that <span><a href=\"www.example.com/1\">example_1</a> </span>is interesting, so \
is <span><a href=\"www.example.com/2\">example_2</a> </span>and also <span><a href=\"www.example.com/3\">example_3</a></span></div>");
        /* eslint-enable */
    });
});
