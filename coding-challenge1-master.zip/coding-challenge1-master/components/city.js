/* @flow */
import * as React from 'react';

type Props = {
    loading: boolean,
    error: ?Error,
    data: ?Object
};

export default function City(props: Props): React.Node {
    if (props.loading) {
        return <div>Loading...</div>;
    }
    if (props.error) {
        return <div>Error!</div>;
    }
    if (props.data) {
        return <h3>{props.data.city}</h3>;
    }
    return null;
}
