/* @flow */
import React from 'react';

type Props = {
    loading: boolean,
    error: ?Error,
    data: ?Object
};

export default function Name(props: Props) {
    if (props.loading) {
        return <div>Loading...</div>;
    }
    if (props.error) {
        return <div>Error!</div>;
    }
    if (props.data) {
        return <h2>{props.data.name}</h2>;
    }
    return null;
}
