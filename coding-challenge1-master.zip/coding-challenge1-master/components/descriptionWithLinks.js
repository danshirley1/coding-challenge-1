/* @flow */
import * as React from 'react';
import Link from './link';

type LinkProps = {
    url: string,
    text: string
};

type Props = {
    description: string,
    links: Array<LinkProps>
};

export default class DescriptionWithLinks extends React.Component<Props> {
    static defaultProps = {
        links: []
    };

    render(): React.Node {
        return <div>{this.renderDescription()}</div>;
    }

    /* Replace specified links in text with hyperlinks (Link components) */
    renderDescription() {
      const { description, links } = this.props;

      return description.split(' ').map((chunk, index, arr) => {
          const customLink = links.find((l) => chunk.includes(l.url));
          const addTrailingWhitespace = index < arr.length - 1;

          if (customLink) return (
            <span key={index}>
              <Link url={customLink.url} children={customLink.text} />
              {addTrailingWhitespace &&
                ' '
              }
            </span>
          );

          return index < arr.length - 1 ? `${chunk} ` : chunk;
      });
    }
}
