// @flow
import * as React from 'react';

type Props = {
    loading: boolean,
    error: ?Error,
    data: ?Object
};

const namedStateMessageHOC = Component => (props: Props) => {
    if (props.loading) {
        return <div>Loading...</div>;
    }
    if (props.error) {
        return <div>Error!</div>;
    }
    if (props.data) {
        return <Component {...props} />;
    }

    return null;
};

export default namedStateMessageHOC;
